package com.example.studentreport.services;

import com.example.studentreport.model.*;
import com.example.studentreport.repositories.StudentDataRepository;
import com.example.studentreport.repositories.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Scope("singleton")
@Service
public class StudentService {
    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private StudentDataRepository studentDataRepository;

    public List<Student> getAllStudents(){
        return studentRepository.findAll();
    }

    public List<StudentData> getAllData(){
        return studentDataRepository.findAll();
    }

    public Optional<Student> getStudentById(Integer id){
        return studentRepository.findById(id);
    }

    public void deleteAllStudents(){
        studentRepository.deleteAll();
    }

    public StudentAverageResponse getStudentDataById(Integer id) {
        List<StudentData> studentDataForAllSems = studentDataRepository.findStudentDataByStudentId(id);
        Student studentDetails = getStudentById(id).orElseThrow();
        Integer mathTotal = 0;
        Integer scienceTotal = 0;
        Integer englishTotal = 0;
        Integer totalSems = studentDataForAllSems.size();
        for (StudentData semData:studentDataForAllSems){
            mathTotal += semData.getMaths();
            scienceTotal += semData.getScience();
            englishTotal += semData.getEnglish();
        }
        //Integer avg = (mathTotal + scienceTotal + englishTotal)/3;
        return new StudentAverageResponse(studentDetails.getFirstName(), studentDetails.getLastName(), mathTotal, scienceTotal, englishTotal);
    }

    public SemesterAverageResponse getSemesterDataById(Integer semId) {
        List<StudentData> semData = studentDataRepository.findSemesterDataBySemId(semId);
        Integer mathTotal = 0;
        Integer scienceTotal = 0;
        Integer englishTotal = 0;
        Integer students = semData.size();

        for (StudentData studentData:semData){
            mathTotal += studentData.getMaths();
            scienceTotal += studentData.getScience();
            englishTotal += studentData.getEnglish();
        }
        return new SemesterAverageResponse(semId, mathTotal, scienceTotal, englishTotal);
    }
}
