package com.example.studentreport.model;

import java.io.Serializable;

public class CompositeKey implements Serializable {
    private Integer semester;
    private Integer id;
}
