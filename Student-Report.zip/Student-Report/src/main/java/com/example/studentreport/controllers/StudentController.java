package com.example.studentreport.controllers;

import com.example.studentreport.model.SemesterAverageResponse;
import com.example.studentreport.model.Student;
import com.example.studentreport.model.StudentAverageResponse;
import com.example.studentreport.model.StudentData;
import com.example.studentreport.services.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping()
public class StudentController {

    @Autowired
    private StudentService service;

    @GetMapping("/index")
    public List<StudentData> index(){
        return service.getAllData();
    }

    @GetMapping("/student/all")
    public List<Student> getAllStudents(){
        return service.getAllStudents();
    }

    @GetMapping("/student")
    public Optional<Student> getStudent(@RequestParam Integer id, @RequestParam List<String> inp){
        System.out.println(inp);
        return service.getStudentById(id);
    }

    @GetMapping("/student/{id}")
    public StudentAverageResponse getStudentData(@PathVariable Integer id){
        return service.getStudentDataById(id);
    }

    @GetMapping("/semester/{id}")
    public SemesterAverageResponse getSemesterData(@PathVariable Integer id){
        return service.getSemesterDataById(id);
    }

    @GetMapping("/student/delete-all")
    public void deleteAll(){
        service.deleteAllStudents();
    }
}


